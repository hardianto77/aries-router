#!/bin/bash
# Auto-refresh pool bypass: ProxyVault site-check -> pool -> restart bypass
J=/tmp/pv_cookie.txt
curl -s -c $J -X POST http://127.0.0.1:8022/api/login -F username=admin -F password=Ar13sV4ult2026 >/dev/null
curl -s -b $J -X POST http://127.0.0.1:8022/api/proxies/test -H 'Content-Type: application/json' -d '{"url":"https://opencode.ai/zen","limit":300}' > /tmp/sc.json 2>/dev/null
python3 - <<'PYEOF'
import json
try:
    d = json.load(open('/tmp/sc.json'))
    passed = [f"http://{r['ip']}:{r['port']}" for r in d.get('results',[]) if r.get('ok')]
except Exception:
    passed = []
if len(passed) >= 5:
    pool = [{"url":"http://127.0.0.1:8118","label":"warp"}]
    pool += [{"url":p,"label":p.split('//')[1][:22]} for p in passed]
    json.dump({"entries":pool}, open('/home/ubuntu/.opencode-free-bridge/proxy.json','w'))
    print("pool refreshed:", len(pool))
PYEOF
systemctl --user restart opencode-bypass opencode-bridge
# Seed pool bridge via API (pool bridge gak persist setelah restart)
sleep 3
python3 - <<'PYEOF2'
import json, urllib.request
try:
    entries = json.load(open('/home/ubuntu/.opencode-free-bridge/proxy.json'))['entries']
    req = urllib.request.Request("http://127.0.0.1:20129/api/proxy", data=json.dumps({"entries":entries}).encode(), headers={"Content-Type":"application/json"})
    urllib.request.urlopen(req, timeout=20)
    print("bridge seeded:", len(entries))
except Exception as e:
    print("seed fail:", e)
PYEOF2
sleep 3
python3 /home/ubuntu/seed_bridge.py >> /home/ubuntu/refresh_pool.log 2>&1
