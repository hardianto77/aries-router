# OpenCode Fix Pack
1. bridge: bun server.js di bridge/ -> :20129 (unit opencode-bridge.service)
2. anti-limit-proxy.py -> :20132 (unit opencode-bypass.service, MAX_RETRY=8)
3. config: opencode.jsonc -> ~/.config/opencode/ (baseURL :21008/v1, key mecombo, model kilo-auto/free)
4. pool.json -> ~/.opencode-free-bridge/proxy.json ; seed: python3 seed_bridge.py
5. crons: refresh_pool.sh tiap 2 jam, pool_watchdog.sh tiap jam
Default model: aries/kilo/kilo-auto/free (fallback combo oc/* + tokenharbor/* di router)
