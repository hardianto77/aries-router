# TUTORIAL: Kenapa & Gimana OpenCode Bisa Jalan (VPS Aries Router)

## 1. Peta Besar (siapa manggil siapa)

    opencode (CLI, ~/.opencode/bin/opencode)
        |  baca config: ~/.config/opencode/opencode.jsonc
        |  provider "aries" -> baseURL http://127.0.0.1:21008/v1 + API key mecombo
        v
    Aries Router (:21008, systemd: aries-router)
        |  distribusi model ke banyak provider pool
        |-- fm/ dahl/ (FreeModel)      -> langsung ke upstream
        |-- kilo/*  -> kilo-relay  (:20130) -> api.kilo.ai
        |-- ovh/*   -> ovh-relay   (:20131) -> oai.endpoints.kepler.ai.cloud.ovh.net
        |-- ocb/*   -> opencode-bridge (:20129) -> OpenCode Zen free models
        |               (egress lewat anti-limit :20132 -> WARP :8118 + 49 proxy resi)
        v
    jawaban streaming balik ke opencode

Semua lokal (127.0.0.1) kecuali hop terakhir -> makanya kenceng.

## 2. Kecepatan hasil benchmark (router internal)
- ovh/gpt-oss-120b        0.3-0.5s   <- tercepat
- bridge glm-5.3-flash-free ~4s     <- default opencode (utama + small_model)
- kilo/kilo-auto/free     ~2s
- dahl/glm-5.3-flash      ~5s

## 3. Config inti (opencode.jsonc)
"provider": { "aries": { "npm": "@ai-sdk/openai-compatible",
  "options": { "baseURL": "http://127.0.0.1:21008/v1", "apiKey": "sk-...(mecombo)" } } }
"model": "aries/openai-compatible-chat-opencode-bridge/glm-5.3-flash-free"
"small_model": (sama)  <- PENTING: kalau gak diset, opencode dobel request lambat
  (title-gen + jawaban). Ini penyebab "lama proses" kemarin.

## 4. Model ID di router
Format: <prefix>/<model>  atau  openai-compatible-chat-<nama>/<model>
Lihat semua: curl -H "Authorization: Bearer <key>" http://127.0.0.1:21008/v1/models
Key mecombo ada di DB: sqlite3 ~/.aries-router/db/data.sqlite
  'SELECT key FROM apiKeys WHERE name="mecombo";'

## 5. Service yang harus hidup (systemd)
- system : aries-router, kilo-relay, ovh-relay
- user   : opencode-bridge, opencode-bypass, hermes-dashboard, hermes-gateway,
           zai-farm, zai-xvfb, pvgate, aws-waf-solver, mail-receiver
Cek: systemctl is-active <nama>  /  systemctl --user is-active <nama>

## 6. Anti-hilang: BUNDLE (di ~/ dan /opt/)
- opencode-bundle.tar.gz       -> binary + config + restore script
- kilo-ovh-relay-bundle.tar.gz -> relay.js + unit + restore script
Restore 1 perintah:
  tar -xzf ~/opencode-bundle.tar.gz -C /tmp && bash /tmp/restore-opencode.sh
  mkdir -p /tmp/ko && tar -xzf ~/kilo-ovh-relay-bundle.tar.gz -C /tmp/ko && sudo bash /tmp/ko/restore-kilo-ovh.sh

## 7. Command harian
opencode                          # mode interaktif
opencode run -m 'aries/kilo/kilo-auto/free' "pertanyaan"
opencode run -m 'aries/ovh/gpt-oss-120b' "pertanyaan ringan, paling ngebut"

## 8. Troubleshooting cepat
- error model_not_found  -> model ID salah; cek /v1/models
- bridge error           -> systemctl --user status opencode-bridge opencode-bypass
- kilo/ovh mati          -> sudo systemctl start kilo-relay ovh-relay
- router 502/timeout     -> systemctl status aries-router; free -m (RAM 2GB, awas full)
- lambat semua           -> cek relay upstream & pool proxy di ~/.opencode-free-bridge/proxy.json
