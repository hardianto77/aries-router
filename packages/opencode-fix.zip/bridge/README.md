# OpenCode Free Bridge (Bun)

Bridge OpenAI-compatible ke OpenCode Zen free models.

Cara pakai: lihat **../README.md** (README utama).

Jalankan:
```bash
bun server.js
```
Listen: http://0.0.0.0:20129

📢 https://t.me/ailootid
