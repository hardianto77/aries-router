#!/bin/bash
# rebuild BrightData pool tiap jam + alert via health
cd /home/ubuntu/opencode_bridge/opencode-bridge
POOL_SIZE=60 /usr/bin/python3 bypass-free-limit.py --build-pool >> /home/ubuntu/opencode_bridge/pool_watchdog.log 2>&1
